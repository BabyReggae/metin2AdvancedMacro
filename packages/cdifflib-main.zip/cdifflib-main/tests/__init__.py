"""
Tests directory.
"""
from . import cdifflib_tests
